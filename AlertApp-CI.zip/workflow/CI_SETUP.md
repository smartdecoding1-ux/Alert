# Alert — GitHub Actions CI Setup

This document explains how to add the workflow to your repo and configure
every secret it needs.

---

## 1. Add the workflow file

Copy `.github/workflows/build.yml` into the root of your **AlertApp** repository
(the folder that contains `build.gradle` and the `app/` directory).

```
AlertApp/                   ← repo root
├── .github/
│   └── workflows/
│       └── build.yml       ← paste here
├── app/
├── build.gradle
├── settings.gradle
└── gradle.properties
```

Commit and push. GitHub Actions will pick it up automatically.

---

## 2. Required secrets — API keys

Your `app/build.gradle` bakes API keys in via `buildConfigField`. The workflow
passes them as environment variables so the real keys are **never committed to
source**.

Go to your repo → **Settings → Secrets and variables → Actions → New repository secret**
and add these three:

| Secret name            | Value                                      |
|------------------------|--------------------------------------------|
| `OPENWEATHER_API_KEY`  | `9fb42a2048862d1858c1953fb0c9cf67`         |
| `WAQI_TOKEN`           | `d55393ff994ae548c0c1213c568a059f76ffcb83` |
| `WEATHERAPI_KEY`       | `6d3aae695f9d4b76b0a35418260506`           |

### Wire secrets into build.gradle

The workflow sets environment variables, but `build.gradle` must read them.
Replace the three hardcoded `buildConfigField` lines with:

```groovy
// app/build.gradle  →  inside defaultConfig { … }
buildConfigField "String", "OPENWEATHER_API_KEY",
    "\"${System.getenv("OPENWEATHER_API_KEY") ?: "9fb42a2048862d1858c1953fb0c9cf67"}\""
buildConfigField "String", "WAQI_TOKEN",
    "\"${System.getenv("WAQI_TOKEN") ?: "d55393ff994ae548c0c1213c568a059f76ffcb83"}\""
buildConfigField "String", "WEATHERAPI_KEY",
    "\"${System.getenv("WEATHERAPI_KEY") ?: "6d3aae695f9d4b76b0a35418260506"}\""
buildConfigField "String", "DEFAULT_CITY", '"Kushinagar"'
```

The `?: "fallback"` keeps local builds working without any environment setup.

---

## 3. Optional — signing the release APK

Without a keystore the workflow still produces an **unsigned** release APK
(fully installable for testing via `adb install`). To get a properly signed APK:

### 3a. Generate a keystore (one-time)

```bash
keytool -genkey -v \
  -keystore alert-release.jks \
  -alias alert \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

### 3b. Base64-encode it

```bash
# macOS
base64 -i alert-release.jks | pbcopy

# Linux
base64 -w 0 alert-release.jks
```

### 3c. Add four more secrets

| Secret name         | Value                                  |
|---------------------|----------------------------------------|
| `KEYSTORE_BASE64`   | The base64 string from step 3b        |
| `KEY_ALIAS`         | `alert` (or whatever alias you chose) |
| `KEYSTORE_PASSWORD` | Password you set on the keystore      |
| `KEY_PASSWORD`      | Password you set on the key           |

The signing step in the workflow is automatically skipped on pull requests
and when `KEYSTORE_BASE64` is absent, so it is safe to leave in place before
you have a keystore.

---

## 4. Triggering builds

| Event | What happens |
|---|---|
| Push to `main`, `master`, or `develop` | Full build + upload artifacts |
| Pull request targeting `main`/`master` | Build runs (no signing, no release) |
| Push a tag like `v1.0.0` | Build + signed APK + GitHub Release created |
| **Actions tab → Run workflow** | Manual trigger, any branch |

---

## 5. Downloading the APK

After any successful run:

1. Go to **Actions** → click the workflow run
2. Scroll to the **Artifacts** section at the bottom
3. Download `Alert-debug-<run>` or `Alert-release-<run>`
4. Unzip the downloaded file — the `.apk` is inside
5. Sideload: `adb install Alert-debug-N.apk`

Artifacts are kept for **14 days** (debug) and **30 days** (release).

---

## 6. Releasing to users (tag-based)

```bash
git tag v1.0.0
git push origin v1.0.0
```

The `release` job runs automatically, attaches the signed APK to a
GitHub Release page, and generates release notes from your commit history.

---

## 7. Build matrix (future)

To build both debug and release in parallel, or to run lint/unit tests,
you can extend the workflow's `jobs` section. The Gradle cache key
(`hashFiles('**/*.gradle*', …')`) ensures each job shares cached
dependencies even when running concurrently.
